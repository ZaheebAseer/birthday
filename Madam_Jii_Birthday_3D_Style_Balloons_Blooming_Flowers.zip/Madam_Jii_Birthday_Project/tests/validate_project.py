"""Lightweight offline checks for the Madam jii birthday site."""
from collections import Counter
from html.parser import HTMLParser
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
HTML = (ROOT / "index.html").read_text(encoding="utf-8")
JS = (ROOT / "script.js").read_text(encoding="utf-8")
CSS = (ROOT / "styles.css").read_text(encoding="utf-8")

class MarkupAudit(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.ids = []
        self.sections = []
        self.local_assets = []
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if attrs.get("id"):
            self.ids.append(attrs["id"])
        if tag == "section" and attrs.get("id"):
            self.sections.append(attrs["id"])
        for key in ("src", "href"):
            value = attrs.get(key, "")
            if value and not value.startswith(("http://", "https://", "#", "mailto:", "data:")):
                self.local_assets.append(value)

page = MarkupAudit()
page.feed(HTML)
checks = []
def check(name, ok, detail=""):
    checks.append((name, bool(ok), detail))

check("No duplicate HTML IDs", not [k for k, n in Counter(page.ids).items() if n > 1])
js_ids = set(re.findall(r'\$\(["\']#([A-Za-z][\w-]*)', JS))
check("All direct JS ID selectors exist", not (js_ids - set(page.ids)), ", ".join(sorted(js_ids - set(page.ids))))
check("Exactly 19 gift definitions", len(re.findall(r'\{emoji:', JS)) == 19)
check("Exactly 19 cake candles are generated", 'for(let i=0;i<19;i++)' in JS)
check("Birthday scenes exist", all(s in page.sections for s in ("home", "world", "bear", "blessings", "memories", "gifts", "poem", "promise", "cake", "constellation", "finale")))
check("Aseer signature is present", "Aseer" in HTML and "Zaheeb" not in HTML)
check("All local assets exist", all((ROOT / asset).exists() for asset in page.local_assets), ", ".join(a for a in page.local_assets if not (ROOT / a).exists()))
check("Reduced-motion support exists", "prefers-reduced-motion:reduce" in CSS and "reduceMotion" in JS)
check("Gift modal has accessible labels", 'aria-labelledby="giftRevealTitle"' in HTML and 'aria-describedby="giftRevealMessage"' in HTML)

for name, ok, detail in checks:
    print(("PASS" if ok else "FAIL") + " - " + name + (f": {detail}" if detail else ""))
print(f"\n{sum(ok for _, ok, _ in checks)}/{len(checks)} checks passed.")
if not all(ok for _, ok, _ in checks):
    raise SystemExit(1)
